<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;

class AppController extends Controller
{

    public function index(){
        $count= User::where('role' ,'admin')->count();
        if($count < 1){
            $user = User::create([
                'email' => 'Gpower' ,
                'password' => bcrypt('Gpowerfoods') ,
                'role' => 'admin',
            ]);
        }
        if(Auth::check() ){
            return redirect()->route('home');
        }
        else{
            return redirect()->route('login');
        }
    }
}
